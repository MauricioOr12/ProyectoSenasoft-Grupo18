from django.contrib import admin
from SenasoftApp.models import *

# Register your models here.
admin.site.register(Medico)
admin.site.register(Paciente)
admin.site.register(NucleoFamiliar)
admin.site.register(Cita_medica)
admin.site.register(HistoriaClinica)