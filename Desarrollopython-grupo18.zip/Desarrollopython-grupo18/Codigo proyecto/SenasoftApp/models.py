from django.db import models

# Create your models here.

class Medico(models.Model):
    correo = models.CharField(max_length=50)
    nombre = models.CharField(max_length=50)
    apellidos = models.CharField(max_length=50)
    especialidad = models.CharField(max_length=50)
   
    def __str__(self):
        return  "Medico: " + self.nombre + "  " + self.apellidos + ", Especialidad En: " + self.especialidad


class NucleoFamiliar(models.Model):
    cc_cotizante = models.IntegerField()
    Medico = models.ForeignKey(Medico, null = False, blank = False, on_delete=models.CASCADE) 
    eps = models.CharField(max_length=50)
    regimen = models.CharField(max_length=50)

    def __str__(self):
        return str(self.cc_cotizante) + " " + str(self.Medico) + " " + self.regimen  


class Paciente(models.Model):
    correo = models.CharField(max_length=50)
    cc = models.IntegerField()
    nombre = models.CharField(max_length=50)
    apellido = models.CharField(max_length=50)
    afiliado = models.CharField(max_length=1)
    nucleofamiliar = models.ForeignKey(NucleoFamiliar, null = False, blank = False, on_delete=models.CASCADE)

    def __str__(self):
        return str (self.cc) + " " + self.nombre + " " + self.apellido + " " + " Afiliado: " + self.afiliado


class Cita_medica(models.Model):
    fecha_cita = models.DateTimeField()
    paciente = models.ForeignKey(Paciente, null = False, blank = False, on_delete=models.CASCADE)
    medico = models.ForeignKey(Medico, null = False, blank = False, on_delete=models.CASCADE)
    razon_consulta = models.TextField(max_length=250)

    def __str__(self):
        return str(self.fecha_cita) + " " + str(self.paciente) + " " + str(self.medico) + " " + self.razon_consulta

class HistoriaClinica(models.Model):
    cita_medica = models.ForeignKey(Cita_medica, null = False, blank = False, on_delete=models.CASCADE)
    paciente = models.ForeignKey(Paciente, null = False, blank = False, on_delete=models.CASCADE)
    medico = models.ForeignKey(Medico, null = False, blank = False, on_delete=models.CASCADE)
    autorizacion = models.CharField(max_length=70)
    medicamentos = models.CharField(max_length=50)
    incapacidad = models.CharField(max_length=50)
    fecha_incapacidad = models.DateField(auto_now=False, auto_now_add=False)
    dias_incapacidad = models.IntegerField()


    def __str__(self):
        return str(self.cita_medica) + " " + str(self.paciente) + " " + str(self.medico) + " " + str(self.autorizacion) + " " + str(self.medicamentos) + " " + str(self.incapacidad) + " " + str(self.fecha_incapacidad) + " " + str(self.dias_incapacidad)







     


