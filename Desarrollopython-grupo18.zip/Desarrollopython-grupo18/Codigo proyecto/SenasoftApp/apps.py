from django.apps import AppConfig


class SenasoftappConfig(AppConfig):
    name = 'SenasoftApp'
